// Declare variables

let totalScore = 0;
let incorrect = 0;
let totalQuestions = 20;
let timer = 5;

let tQuestions = [];

let diff = "../data/easyQ.json";

let qNum = 0;

let interval;

// Grab all of Html elements

// correct, counter, questions, buttons - using a class

let correct = document.getElementById('correct');
let counter = document.getElementById('counter');
let questions = document.getElementById('questions');

let a1 = document.getElementById('a1');
let a2 = document.getElementById('a2');
let a3 = document.getElementById('a3');
let a4 = document.getElementById('a4');
// Get buttons by class

let buttons = document.getElementsByClassName("btn");

for (let i = 0; i < buttons.length; i++) {
    buttons[i].addEventListener('click', function (e) {
    //alert("You Clicked a Button");
    //checkAnswer(buttons[i].innerText)
    checkAnswer(e.toElement.innerText);
    });
    //asdf
}

//
function loadJSON(url) {
    let xmlhttp = new XMLHttpRequest();

    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            // let myArr = JSON.parse(this.response.Text);
            // tQuestions = myArr.ezQ;
            tQuestions = JSON.parse(this.responseText).ezQ;
            console.log(tQuestions);
            interval = setInterval(updateTime, 1000);
            loadQuestion();
            //myFunction(myArr);
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
//-----------------------------------//

function loadQuestion(){
    
    //Load the next questions
    questions.innerText = tQuestions[qNum].q;
    a1.innerText = tQuestions[qNum].a1;
    a2.innerText = tQuestions[qNum].a2;
    a3.innerText = tQuestions[qNum].a3;
    a4.innerText = tQuestions[qNum].a4;
}

function checkAnswer(answer){
    //Retrieve the answer and see if it is correct
    //Increment your correct number

    if(answer === tQuestions[qNum].qa){
        totalScore++;
    }
    else{
        incorrect++;
    }
    console.log('Console Log');
    correct.innerText=`${totalScore}/${totalQuestions}`;
    timer = 5;
    counter.innerText=timer;
    nextQuestion();
}

//aaa
function nextQuestion(){
//Prep
//aaa
if(qNum < totalQuestions){
    // will run until you hit total questions = 20
    qNum++;
    loadQuestion();
    }
    else{
        //load ending page
        clearInterval(interval);
        alert("You have finished the game!!");
    }
}

//------------ Set Timer --------------//

function updateTime(){
    //Make sure time isn't over and that it's showing correct time

    timer--;
    if(timer == 0){
        timer=5;
        counter.innerText=timer;
        nextQuestion();
    }
    else{
        counter.innerText=timer;
    }
}

//----------------------------------//
loadJSON(diff);