//Init Variables
let totalQuestions = 20;
let diff = "easy"; // Can be medium or hard also
let triviaQ = [];

function LoadQuestions() {
    let xmlhttp = new XMLHttpRequest();
    let url = "";

    if(diff == "easy"){
        url= "../data/easyQ.json";
    }
    else if(diff == "medium"){
        url= "../data/mediumQ.json";
    }
    else if(diff == "hard"){
        url= "../data/hardQ.json";
    }
    else{
        url= "../data/easyQ.json";
    }
    
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let myArr = JSON.parse(this.responseText);
            allQuestions(myArr);
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

function allQuestions(asdf){
    console.log(asdf.ezQ[26]);
    let qNum = 0;
    for(let i = 0; i < totalQuestions; i++){
    qNum = Math.floor(Math.random() * asdf.ezQ.length);
    //console.log(qNum);
    triviaQ.push(asdf.ezQ[qNum]);
    asdf.ezQ.splice(qNum, 1);

    }
    console.log(triviaQ);


}

LoadQuestions();